# ENTREGA - Práctica 2 MPP (MPI)

Una carpeta por cuestion (C2, C3, C4, C5, C6) con el codigo usado en
la práctica para generar la salida listo para
compilar y ejecutar.

Estructura de cada cuestion:

Cx/
└── codigo/
    ├── src/         main.c, io.c, mh.c, Makefile, run.sh, prestaciones.sh, prestaciones_fijo.sh
    ├── include/     io.h, mh.h
    ├── igen/        generador de ficheros de entrada (igen.cpp, in.txt, Makefile, run.sh)
    ├── input/       matrices de distancias de prueba
    └── output/      prestaciones.txt, prestaciones_fijo.txt (referencia)



Compilar (desde codigo/src):
    make clean
    make mpi         # version normal (con convergencia)  -> ./mpi
    make mpi_fijo    # version trabajo fijo (-DSIN_CONVERGENCIA) -> ./mpi_fijo

Ejecutar un ejemplo (desde codigo/src):
    mpirun --oversubscribe -np 4 ./mpi 2000 800 400 200 0.3 10 3 < ../input/input_2000_800_400_200_0.3.txt

Medir prestaciones (desde codigo/src; los scripts compilan solos y anexan a output/):
    ./prestaciones.sh        # np = 1 2 4 6 8, 5 repeticiones
    ./prestaciones_fijo.sh   # trabajo fijo, np = 1 2 4 6 8, 3 repeticiones

Requisitos: openmpi-bin, libopenmpi-dev (mpicc, mpirun). Si falta carpeta
input/ o se quieren otras instancias, generarlas con codigo/igen/ (ver in.txt).

