#!/bin/bash
# Genera todas las matrices de distancias indicadas en in.txt.
# Cada línea de in.txt tiene: n m n_gen tam_pob m_rate
set -e
cd "$(dirname "$0")"

make igen

while read -r line; do
	[[ -z "$line" || "$line" == \#* ]] && continue
	n=$(echo "$line" | awk '{print $1}')
	m=$(echo "$line" | awk '{print $2}')
	gen=$(echo "$line" | awk '{print $3}')
	tam=$(echo "$line" | awk '{print $4}')
	mrate=$(echo "$line" | awk '{print $5}')
	make exe_igen N="$n" M="$m" N_GEN="$gen" T_POB="$tam" M_RATE="$mrate"
done < in.txt
