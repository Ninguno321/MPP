#!/bin/bash
# ============================================================================
# Configuración de los experimentos de la Práctica 2 (MPI)
# Puedes editar este fichero sin tocar el código ni los scripts.
# ============================================================================

# --- Instancia principal de prestaciones -----------------------------------
# n  m  n_gen  tam_pob  m_rate
export P2_INSTANCIA_PRINCIPAL="2000 800 400 200 0.3"

# --- Instancia pequeña para el barrido de NGM y NEM ------------------------
export P2_INSTANCIA_SWEEP="1000 400 200 100 0.3"

# --- Parámetros del modelo de islas ----------------------------------------
# Valores de partida de las cuestiones 2 a 5.
export P2_NGM_INICIAL=10
export P2_NEM_INICIAL=3

# Configuración final de la Cuestión 6. Se mantienen los mismos valores que en
# las cuestiones 2 a 5 (NGM=10, NEM=3), como en el código base del repositorio.
# El barrido de bench.py se usa solo para justificar que estos valores son
# razonables; no se cambia la configuración final.
export P2_NGM=10
export P2_NEM=3

# --- Repeticiones y procesos ------------------------------------------------
# REPS: ejecuciones por configuración en los experimentos con convergencia.
# REPS_FIJO: ejecuciones por configuración en los experimentos de trabajo fijo.
export P2_REPS=5
export P2_REPS_FIJO=3

# Número de generaciones de la versión de trabajo fijo (sin convergencia).
export P2_N_GEN_FIJO=60

# Procesos MPI que se prueban en las tablas de prestaciones.
export P2_PROCESOS="1 2 4 6 8 10 12 16"

# Procesos MPI del barrido de NGM/NEM (se recomienda 6, el número de núcleos
# físicos de la máquina).
export P2_PROCESOS_SWEEP="6"

# Valores de NGM y NEM que se prueban en el barrido.
export P2_NGM_VALUES="5 10 20 50"
export P2_NEM_VALUES="1 3 5"

# Tiempo máximo (segundos) de una ejecución individual. Si se supera, el
# script la marca como fallida en lugar de quedarse colgado.
export P2_TIMEOUT=600

# Comando de MPI. Normalmente mpirun.
export P2_MPIRUN="mpirun"
